<html>
<head>
    <title> Product List </title>
</head>

<style>
	body {
	background-image: url('back.jpg');
	background-repeat: no-repeat;
  background-attachment: fixed;  
  background-size: cover;
}

</style>
	<body>
	<div style="padding-top:0.2cm;padding-bottom:0.4cm;background-color:black; color:white;height:30px">
	 <h2 <p   style="text-align:left"> Product List   </p> <h2>  </div> 
	 <table style="width:80%">
	 
  <tr>
    <th style="text-align:left; padding-left:20px">images</th>
    <th style="text-align:left; padding:20px">Name</th>
    <th style="text-align:left">Price</th>
	<th style="text-align:left"><button name="add" value="add new">Add New</button></th>

  </tr>
  <tr>
  <td><p style="text-align:left"><img src="./mobile.jpg"  height="100" width="100" align="left"></p></td>
    <td>Realme</td>
    <td>12333</td>
	<td><button name="add" value="add new">Delete</button>
  </tr>
  <tr>
    <td><p style="text-align:left"><img src="./mobile1.jpg" height="100" width="100" align="left"></p></td>
    <td>Vivo</td>
    <td>12365</td>
	<td><button name="add" value="add new">Delete</button>
  </tr>
  <tr>
  
    <td><p style="text-align:left"><img src="./mobile2.jpg" height="100" width="100" align="left"></p></td>
    <td>Honor</td>
    <td>123654</td>
	<td><button name="add" value="add new">Delete</button>
  </tr>
  <tr>
    <td><p style="text-align:left"><img src="./mobile4jpg.jpg" height="100" width="100" align="left"></p></td></td>
    <td>micromax</td>
    <td>6789</td>
	<td><button name="add" value="add new">Delete</button>
  </tr>
  <tr>
   
</table>
	 
	 
	 
	 
	 
</html>
</body>	
	
	
