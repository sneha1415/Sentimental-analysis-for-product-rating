<!DOCTYPE html>
<html>
<head>
<style>
body {
	background-image: url('back.jpg');
	background-repeat: no-repeat;
  background-attachment: fixed;  
  background-size: cover;
}

</style>
<link rel="stylesheet"  type"text/css"   href="ext.css"></link>
<title>Products</title>
</head>
<body >
<div id="updiv">
	<a href= "login.php" button class="but" type="submit" name="Login"><b> Login</b></button></a>  	
	<a href= "signup.php" button class="but" type="submit" name="Signup" ><b> Signup</b></button></a>  
	
</div>
<div id="div2">
	<h1>Welcome to Online Shopping Mart</h1>
</div>
<div id="div3">
<pre>
	<a href="homepage.php" class="ref">Home</a>			<a href="product2.php"class="ref">Electronics</a>			<a href="comming.html"class="ref">Furniture</a>			<a href="comming.html"class="ref">Clothing</a>
</pre>
</div>
<div class="row1">
<div id="div4" class="column1">
<pre>
<h1>Brands</h1>
<a href="samsungwologin.php" class="ref">Samsung</a><br><br>
<a href="applewologin.php" class="ref">apple</a><br><br>
<a href="oppowologin.php" class="ref">oppo</a><br><br>
<a href="onepluswologin.php" class="ref">oneplus</a><br><br>
<a href="redmiwologin.php" class="ref">Redmi</a>
</div>
<div class="column1">
<marquee behavior="scroll" direction="left">
    <img src="img1.jpg" width="800" height="300" alt="Natural" />
<img src="img5.jpg" width="800" height="300" alt="Natural" />
<img src="sale.jpg" width="800" height="300" alt="Natural" / >
  </marquee>
  </div>
  </div>
<div>
<img src="50off.jpg" style =" heigth:600px;width:1200px;margin-left:200px">
</div>
</body>
</html>



	